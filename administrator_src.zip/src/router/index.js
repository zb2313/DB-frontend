import Vue from 'vue'
import VueRouter from 'vue-router'
import Home from '../views/Home.vue'

Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    name: 'Home',
    component: Home
  },
  {
    path: '/personalpage',
    name: 'Personalpage',
    component: () => import('../views/Personalpage.vue')
  },
  {
    path: '/audit',
    name: 'Audit',
    component: () => import('../components/Audit.vue')
  },
  {
    path: '/sendmail',
    name: 'SendMail',
    component: () => import('../components/SendMail.vue')
  },
  {
    path: '/updateQA',
    name: 'UpdateQA',
    component: () => import('../components/UpdateQA.vue')
  },
  {
    path: '/uploadQA',
    name: 'UploadQA',
    component: () => import('../components/UploadQA.vue')
  }
]

const router = new VueRouter({
  routes
})

export default router
