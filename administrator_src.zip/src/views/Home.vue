<template>
 <div id="homeimg"><img src="../assets/lvdao.png" width="700px" height="700px">
    </div>

</template>
<style>
#homeimg{
  position: absolute;
  top:0;
  left: 30%;
}
</style>
