<template>
  <div id="app">
   <div id="bkimg"><img src="../src/assets/bimage.jpg" width="100%" height="100%" alt="">
    </div>
    <span id="menu">
  
    <el-form>
      <el-form-item>
        <router-link to="/">
      <el-button class="el-icon-s-home" id="homebutton" circle ></el-button>
      </router-link> 
      </el-form-item>
      
      <el-form-item>
        <router-link to="/personalpage">
        <el-button>
        <i class="el-icon-s-custom"></i>
       个人基础信息
        </el-button>
        </router-link>
      </el-form-item>
      
      <el-form-item>
      <router-link to="/audit">
        <el-button>
        <i class="el-icon-chat-dot-round"></i>
       审核动态信息
        </el-button>
        </router-link>
      </el-form-item>
      
     
      <el-form-item> 
        <router-link to="/updateQA">
         <el-button>
          <i class="el-icon-document"></i>
       更新常见问题
        </el-button>  
        </router-link>
      </el-form-item>
    
      
      <el-form-item>
        <router-link to="/sendmail">
       <el-button>
          <i class="el-icon-message"></i>
      发送邮件通知
       </el-button>
       </router-link>
      </el-form-item>
      
    </el-form>
    </span>
    <router-view/>
  </div>
</template>

<style>
#app {
  
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: left;
}
#bkimg{
  position: absolute;
  top:0;
  left:0;
  right: 0;
  bottom:0;
}
#menu{
  position: relative;
  top:20px;
  left:20px;
}
#homebutton{
position:relative;
left: 50px;
}
.page{
  position:absolute;
  top: 150px;
  left:350px;
}
</style>
