<template>
    <div class="page">
       <h2>打算参照浏览动态的样式来做
       </h2>
    </div>
</template>
